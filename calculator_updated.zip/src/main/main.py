from src.sq_calc import calc
import sys


def main():
    x= (sys.argv[1])
    res = calc.one_by_x(x)
    print(res)
