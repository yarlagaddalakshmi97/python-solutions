"""test cases for 1/x"""
import unittest
from src.sq_calc import calc


class CalculatorTest(unittest.TestCase):
    """test case"""


    def test_one_by_x_value(self):
        """input=1"""
        res=calc.one_by_x(1)
        self.assertEqual(res, 1)

    def test_one_by_x_zero_division_error(self):
        """input=0"""
        self.assertEqual(calc.one_by_x(0), "ZeroDivisionError")

    def test_one_by_x_value_error(self):
        """input=giving string instead of number"""
        result = calc.one_by_x("s")
        self.assertEqual(result, "ValueError")

    def test_one_by_x_value5(self):
        """when we take 5 as input"""
        result=calc.one_by_x(5)
        self.assertEqual(result,  0.2)


if __name__ == "__main__":
    unittest.main()
